import Foundation

//func solution(_ strings:[String], _ n:Int) -> [String] {
//    
//    var aa = strings.map{ $0[n]}
//    print(aa)
//    
//    return []
//}
